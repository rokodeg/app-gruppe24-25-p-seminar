    // Funktion, um alle Anfragen aus LocalStorage zu löschen
    function clearAllRequests() {
      if (confirm("Möchten Sie wirklich alle Anfragen löschen?")) {
        localStorage.removeItem('anfragen');
        localStorage.removeItem('confirmedRequests');
        localStorage.removeItem('rejectedRequests');
        loadRequests();  // Anfragen neu laden, nachdem sie gelöscht wurden
        loadConfirmedRequests();
        loadRejectedRequests();
      }
    } 
 
 
  // Funktion, um die Anfragen anzuzeigen
    function loadRequests() {
      const anfragen = JSON.parse(localStorage.getItem('anfragen')) || [];
      const anfragenListContainer = document.getElementById('anfragenList');
      anfragenListContainer.innerHTML = '';  // Leere den Container, bevor neue Anfragen hinzugefügt werden

      if (anfragen.length > 0) {
        anfragen.forEach(function(anfrage, index) {
          const anfrageDiv = document.createElement('div');
          anfrageDiv.classList.add('anfrage-container');
          
          // Erstelle HTML-Inhalt für jede Anfrage
          anfrageDiv.innerHTML = 
            <div class="anfrage">
              <h3>${anfrage.name}</h3>
              <p><strong>Fach:</strong> ${anfrage.fach}</p>
              <p><strong>Stundenanzahl:</strong> ${anfrage.stunden}</p>
              <p><strong>Zusätzliche Infos:</strong> ${anfrage.info || 'Keine zusätzlichen Infos'}</p>
              <button onclick="confirmRequest(${index})">Bestätigen</button>
              <button class="reject-btn" onclick="rejectRequest(${index})">Ablehnen</button>
              <button class="delete-btn" onclick="deleteRequest(${index})">Löschen</button>
            </div>
          ;
          
          // Füge die Anfrage zum Container hinzu
          anfragenListContainer.appendChild(anfrageDiv);
        });
      } else {
        anfragenListContainer.innerHTML = '<p>Keine Anfragen vorhanden.</p>';
      }
    }

    // Funktion, um eine Anfrage zu bestätigen
    function confirmRequest(index) {
      const anfragen = JSON.parse(localStorage.getItem('anfragen')) || [];
      const confirmedRequests = JSON.parse(localStorage.getItem('confirmedRequests')) || [];

      // Bestätigte Anfrage zur Liste hinzufügen
      confirmedRequests.push(anfragen[index]);

      // Bestätigte Anfragen im LocalStorage speichern
      localStorage.setItem('confirmedRequests', JSON.stringify(confirmedRequests));

      // Entferne die bestätigte Anfrage aus der Liste
      anfragen.splice(index, 1);
      localStorage.setItem('anfragen', JSON.stringify(anfragen));

      loadRequests();  // Aktualisiere die Anzeige
      loadConfirmedRequests();  // Aktualisiere die bestätigten Anfragen
    }

    // Funktion, um eine Anfrage abzulehnen
    function rejectRequest(index) {
      const anfragen = JSON.parse(localStorage.getItem('anfragen')) || [];
      const rejectedRequests = JSON.parse(localStorage.getItem('rejectedRequests')) || [];

      // Abgelehnte Anfrage zur Liste hinzufügen
      rejectedRequests.push(anfragen[index]);

      // Abgelehnte Anfragen im LocalStorage speichern
      localStorage.setItem('rejectedRequests', JSON.stringify(rejectedRequests));

      // Entferne die abgelehnte Anfrage aus der offenen Liste
      anfragen.splice(index, 1);
      localStorage.setItem('anfragen', JSON.stringify(anfragen));

      loadRequests();  // Aktualisiere die Anzeige
      loadRejectedRequests();  // Aktualisiere die abgelehnten Anfragen
    }

    // Funktion, um eine Anfrage zu löschen
    function deleteRequest(index) {
      const anfragen = JSON.parse(localStorage.getItem('anfragen')) || [];
      anfragen.splice(index, 1);
      localStorage.setItem('anfragen', JSON.stringify(anfragen));

      loadRequests();  // Aktualisiere die Anzeige
      loadConfirmedRequests();  // Aktualisiere die bestätigten Anfragen
      loadRejectedRequests();  // Aktualisiere die abgelehnten Anfragen
    }

    // Funktion, um bestätigte Anfragen anzuzeigen
    function loadConfirmedRequests() {
      const confirmedRequests = JSON.parse(localStorage.getItem('confirmedRequests')) || [];
      const confirmedRequestsListContainer = document.getElementById('confirmedRequestsList');
      confirmedRequestsListContainer.innerHTML = '';  // Leere den Container, bevor neue Anfragen hinzugefügt werden

      if (confirmedRequests.length > 0) {
        confirmedRequests.forEach(function(anfrage) {
          const anfrageDiv = document.createElement('div');
          anfrageDiv.classList.add('anfrage-container');
              confirmedRequestsListContainer.appendChild(anfrageDiv);
        });
      } else {
        confirmedRequestsListContainer.innerHTML = '<p>Keine bestätigten Anfragen vorhanden.</p>';
      }
    }

    // Funktion, um abgelehnte Anfragen anzuzeigen
    function loadRejectedRequests() {
      const rejectedRequests = JSON.parse(localStorage.getItem('rejectedRequests')) || [];
      const rejectedRequestsListContainer = document.getElementById('rejectedRequestsList');
      rejectedRequestsListContainer.innerHTML = '';  // Leere den Container, bevor neue Anfragen hinzugefügt werden

      if (rejectedRequests.length > 0) {
        rejectedRequests.forEach(function(anfrage) {
          const anfrageDiv = document.createElement('div');
          anfrageDiv.classList.add('anfrage-container');
                    rejectedRequestsListContainer.appendChild(anfrageDiv);
        });
      } else {
        rejectedRequestsListContainer.innerHTML = '<p>Keine abgelehnten Anfragen vorhanden.</p>';
      }
    }

    // Funktion, um das Einklappen der bestätigten Anfragen umzuschalten
    function toggleConfirmedRequests() {
      const confirmedRequestsList = document.getElementById('confirmedRequestsList');
      const button = document.querySelector('.show-confirmed-requests');

      // Umschalten der Sichtbarkeit
      if (confirmedRequestsList.style.display === 'none' || confirmedRequestsList.style.display === '') {
        confirmedRequestsList.style.display = 'block';
        button.textContent = 'Bestätigte Anfragen verstecken';
      } else {
        confirmedRequestsList.style.display = 'none';
        button.textContent = 'Bestätigte Anfragen anzeigen';
      }
    }

    // Funktion, um das Einklappen der abgelehnten Anfragen umzuschalten
    function toggleRejectedRequests() {
      const rejectedRequestsList = document.getElementById('rejectedRequestsList');
      const button = document.querySelector('.show-rejected-requests');

      // Umschalten der Sichtbarkeit
      if (rejectedRequestsList.style.display === 'none' || rejectedRequestsList.style.display === '') {
        rejectedRequestsList.style.display = 'block';
        button.textContent = 'Abgelehnte Anfragen verstecken';
      } else {
        rejectedRequestsList.style.display = 'none';
        button.textContent = 'Abgelehnte Anfragen anzeigen';
      }
    }

    // Lade die Anfragen, wenn die Seite geladen wird
    window.onload = function() {
      loadRequests();  // Lade die offenen Anfragen
      loadConfirmedRequests();  // Lade die bestätigten Anfragen
      loadRejectedRequests();  // Lade die abgelehnten Anfragen
    }