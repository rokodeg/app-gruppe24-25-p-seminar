// Funktion, um das Formular zu validieren und abzusenden
function submitForm() {
  const name = document.getElementById('name').value;
  const nachname = document.getElementById('nachname').value;
  const fach = document.getElementById('fach').value;
  const wohnort = document.getElementById('wohnort').value;
  const stunden = document.getElementById('stunden').value;
  const klassenstufe = document.getElementById('klassenstufe').value;
  const dringlichkeit = document.getElementById('dringlichkeit').value;
  const kontakt = document.getElementById('kontakt').value;
  const errorMessage = document.getElementById('error-message');

  // Prüfung, ob alle Felder ausgefüllt sind
  if (!name || !nachname || !fach || !wohnort || !stunden || !klassenstufe || !dringlichkeit || !kontakt) {
    errorMessage.textContent = 'Bitte füllen Sie alle Felder aus.';
    return false; // Verhindert das Absenden des Formulars
  }

  // Optional: Speichern der Anfrage im LocalStorage oder Absenden an einen Server
  const anfrage = {
    name: name,
    nachname: nachname,
    fach: fach,
    wohnort: wohnort,
    stunden: stunden,
    klassenstufe: klassenstufe,
    dringlichkeit: dringlichkeit,
    kontakt: kontakt
  };

  // Speichern der Anfrage im LocalStorage (optional)
  let anfragen = JSON.parse(localStorage.getItem('anfragen')) || [];
  anfragen.push(anfrage);
  localStorage.setItem('anfragen', JSON.stringify(anfragen));

  // Erfolgreiche Anfrage-Absenden
  alert('Ihre Anfrage wurde erfolgreich abgesendet!');
  document.getElementById('anfrageForm').reset(); // Formular zurücksetzen
  return false; // Verhindert das Absenden der Seite (falls in einer echten App an einen Server gesendet wird, sollte dies angepasst werden)
}
